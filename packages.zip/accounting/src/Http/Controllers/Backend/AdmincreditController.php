<?php

namespace Packages\Accounting\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Packages\Accounting\Models\Admincredit;
use Packages\Accounting\Models\Sort\Backend\DepositSort;
use Illuminate\Http\Request;

class AdmincreditController extends Controller
{
    /**
     * Deposits listing
     *
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index(Request $request)
    {
       echo "hello wrold";
    }
}
