<?php

namespace Packages\Accounting\Models;

use Packages\Accounting\Models\Fields\EnumWithdrawalMethodStatus;
use Illuminate\Database\Eloquent\Model;

class WithdrawalMethod extends Model implements EnumWithdrawalMethodStatus
{
    //
}
