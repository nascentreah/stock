<?php return [
  'balance_not_sufficient' => 'Jūsu konta atlikums nav pietiekams, lai piedalīties šajā konkursā.',
  'fees_paid' => 'Maksas',
  'reward_paid' => 'Izmaksāto atlīdzību',
];