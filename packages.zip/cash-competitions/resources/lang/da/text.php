<?php return [
  'balance_not_sufficient' => 'Din saldo er ikke tilstrækkelig til at deltage i denne konkurrence.',
  'fees_paid' => 'Gebyrer',
  'reward_paid' => 'Belønning betalt',
];