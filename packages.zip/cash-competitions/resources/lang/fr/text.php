<?php return [
  'balance_not_sufficient' => 'Votre solde n\'est pas suffisant pour se joindre à cette compétition.',
  'fees_paid' => 'Les frais payés',
  'reward_paid' => 'Récompense payé',
];