<?php return [
  'balance_not_sufficient' => 'Uw saldo is niet voldoende mee te doen aan deze wedstrijd.',
  'fees_paid' => 'Vergoedingen die worden betaald',
  'reward_paid' => 'Beloning betaald',
];