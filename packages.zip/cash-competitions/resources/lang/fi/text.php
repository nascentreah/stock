<?php return [
  'balance_not_sufficient' => 'Saldosi ei ole riittävä liity tähän kilpailuun.',
  'fees_paid' => 'Palkkiot',
  'reward_paid' => 'Palkkio maksetaan',
];