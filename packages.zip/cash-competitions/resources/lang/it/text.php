<?php return [
  'balance_not_sufficient' => 'Il tuo saldo non è sufficiente per partecipare a questo concorso.',
  'fees_paid' => 'Tasse pagate',
  'reward_paid' => 'Premio pagato',
];