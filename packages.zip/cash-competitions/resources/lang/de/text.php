<?php return [
  'balance_not_sufficient' => 'Ihr Guthaben ist nicht ausreichend, um sich diesem Wettbewerb.',
  'fees_paid' => 'Gebühren bezahlt',
  'reward_paid' => 'Belohnung bezahlt',
];